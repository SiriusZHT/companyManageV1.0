<template>
<div class="center">
    <span>管理员中心 / 管理用户</span>
    <br/>
    <hr/>

    <!-- 在这里写东西 -->
    
</div>
    
    
</template>

<style scoped>
.center{
    height: 100%;
    /* border: 1px solid black; */
    width: 90%;
    margin-left:5%;
}

span{
    font-size: 12px;
    font-family: sans-serif;
    color: grey;
}
</style>