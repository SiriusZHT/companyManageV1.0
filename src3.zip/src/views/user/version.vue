<template>
<div class="center">
    <span>版本库</span>
    <br/>
    <hr/>
</div>
    
    
</template>

<style scoped>
.center{
    height: 100%;
    /* border: 1px solid black; */
    width: 90%;
    margin-left:5%;
}

span{
    font-size: 12px;
    font-family: sans-serif;
    color: grey;
}
</style>