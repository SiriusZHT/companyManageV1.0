import Vue from 'vue'
import Vuex from 'vuex'

// import VuexPersistence from 'vuex-persist'

Vue.use(Vuex)


export default new Vuex.Store({
  
  state: {
    token:'',
    showfirst:true,
  },
  mutations: {
    change(state,showfirst){
      state.showfirst = showfirst
    },

    set_token(state,token) { 
      state.token = token 
      sessionStorage.token = token 
      sessionStorage.setItem("token",token);
    },

    del_token(state) { 
      state.token = ''
      sessionStorage.removeItem('token') 
    },
  },


  actions: {
  },
  modules: {
  }
})
